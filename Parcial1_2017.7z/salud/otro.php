$contador = count($departamentos);
for($i=0;$i<$contador;$i++){
    if($departamentos[$i] ==$depart){
        echo
   "<table border=1>
    <tr>
    <th>Posicion </th>
    <th>Departmentos</th>
    <th>Municipios</th>
    <th>Capitales</th>
    <th>superficie</th>
    <th>Poblacion</th>
    <th>Region</th>
    </tr>
    <tr>
    <td>$i</td>
    <td>$depart</td>
    <td>$municipios[$i]</td>
    <td>$capitales[$i]</td>
    <td>$superficie[$i]</td>
    <td>$poblacion[$i]</td>
    <td>$region[$i]</td>
    </tr>
    </table>";
    }
}
