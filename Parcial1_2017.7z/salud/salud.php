<?php
//Captura de Datos
$nom = $_POST['nom'];
$ape = $_POST['ape'];
$sel1 = $_POST ['seledad'];
$sel2 = $_POST ['selplan'];
$sel3 = $_POST ['selsex'];
$sel4 = $_POST ['selepe'];
$sel5 = $_POST ['selgo'];
//Declaracion

$men =0;
$dessex=0;
$cosef=0;
$cosgo =0;

// GRUPO PLAN PLATA

if ($sel2 == "PLAN PLATA" && $sel1 =="0-35"){
  $men=0;
}

if ($sel2 == "PLAN PLATA" && $sel1 =="0-59"){
  $men=200000;
}
if ($sel2 == "PLAN PLATA" && $sel1 =="60-85"){
  $men=250000;
}
if ($sel2 == "PLAN PLATA" && $sel1 =="85+"){
  $men=650000;
}

// GRUPO PLAN ORO

if ($sel2 == "PLAN ORO" && $sel1 =="0-35"){
  $men=0;
}

if ($sel2 == "PLAN ORO" && $sel1 =="0-59"){
  $men=240000;
}
if ($sel2 == "PLAN ORO" && $sel1 =="60-85"){
  $men=480000;
}
if ($sel2 == "PLAN ORO" && $sel1 =="85+"){
  $men=1100000;
}

// GRUPO PLAN PLATINO

if ($sel2 == "PLAN PLATINO" && $sel1 =="0-35"){
  $men=0;
}

if ($sel2 == "PLAN PLATINO" && $sel1 =="0-59"){
  $men=350000;
}
if ($sel2 == "PLAN PLATINO" && $sel1 =="60-85"){
  $men=340000;
}
if ($sel2 == "PLAN PLATINO" && $sel1 =="85+"){
  $men=1500000;
}

// GRUPO PLAN JOVEN

if ($sel2 == "PLAN JOVEN" && $sel1 =="0-35"){
  $men=220000;
}

if ($sel2 == "PLAN JOVEN" && $sel1 =="0-59"){
  $men=0;
}
if ($sel2 == "PLAN JOVEN" && $sel1 =="60-85"){
  $men=0;
}
if ($sel2 == "PLAN JOVEN" && $sel1 =="85+"){
  $men=0;
}
//COSTO DE ENFERMEDAD PRE_EXISTENTE
if($sel4 == "DIABETES"){
 $cosef=25000;
}
if($sel4 == "HIPERTENSION"){
 $cosef=32000;
}
if($sel4 == "CARDIOVASCULAR"){
 $cosef=40000;
}
//COSTO DE GRADO DE OBESIDAD
if($sel5 == "<18.5"){
 $cosgo = 15000;
}
if($sel5 == "18.5-24.9"){
 $cosgo=0;
}
if($sel5 == "25-26.9"){
 $cosef=10000;
}
if($sel5 == "27-29.9"){
 $cosgo = 15000;
}
if($sel5 == "30-34.9"){
 $cosgo=20000;
}
if($sel5 == "35-39.9"){
 $cosgo=35000;
}
if($sel5 == "40-49.9"){
 $cosgo=50000;
}
if($sel5 == ">50"){
 $cosgo=100000;
}

if($sel3== "FEMENINO"){
  $dessex=0.10;
  $suma=($men+$cosef+$cosgo)*$dessex;
}else{
  $suma =$men+$cosef+$cosgo;
}


echo "EL Usuario $nom $ape\n  Su mensualidad  $men \nsu Costo por enfermedad pre existentes $cosef\n costo de grado de obesidad $cosgo\n descuento $dessex\n el total a pagar es $suma";
?>
