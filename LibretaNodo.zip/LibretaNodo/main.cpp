//
//  main.cpp
//  LibretaNodo
//
//  Created by JDMR on 24/02/17.
//  Copyright (c) 2017 JDMR. All rights reserved.
//

#include <iostream>
#include <stdlib.h>


using namespace std;

struct Nodo{
	int id;
        string Nombre;
        string direccion;
        string ciudad;
        int numero;
	Nodo *siguiente;
};

//Prototipos de Funciones
void insertarLista(Nodo *&,int,string,string,string,int);
void mostrarLista(Nodo *);
void buscarLista(Nodo *,int);
void borrar(Nodo *,int );

Nodo *lista = NULL;
Nodo *q = NULL;

Nodo *nuevo_nodo = new  Nodo;

  int ele,dat,valor,nbuscar,ne,n,ntel;
  string nom,cui,dir;

int main(int argc, const char * argv[])
{

    
  
    
    do{
        // Menu principal
      //  cout << endl;
        cout << "Escoja una opcion:" << endl;
        cout << "1.- Insertar" << endl;
        cout << "2.- Eliminar" << endl;
        cout << "3.- Buscar" << endl;
        cout << "4.- Lista" << endl;
        cout << "5.- Salir" << endl;
        
        cin >> ele;
        
        switch (ele) { // Switch
            case 1:
                cout<< "Menu de Insertar"<< endl;
                cout<<"\nDigite ID (SOLO NUMEROS) : ";
                cin>>dat;
                cout<<"\nDigite Nombre :";
                cin>>nom;
                cout<<"\nDigite Ciudad :";
                cin>>cui;
                cout<<"\nDigite Dirrecion :";
                cin>>dir;
                cout<<"\nDigite Numero telefono :";
                cin>>ntel;
                insertarLista(lista,dat,nom,cui,dir,ntel);
                cout<<"\n";
                break;
            case 2:
                cout<< "Menu de Eliminar "<< endl;
                cout << "\n Digite el ID a eliminar"<< endl;
                cin >> ne;
                borrar(lista,ne);
                break;
            case 3:
                cout << "Digite ID a buscar \n"<<endl;
                cin >> nbuscar;
                buscarLista(lista,nbuscar);
                break ;
            case 4:
                cout << "Lista de Nodos organizado por ID\n";
                mostrarLista(lista);
                cout<<"\n";
                break;
            case 5:
                cout << "Salir....."<<endl;
                break;
            default:
                cout << "Opcion no existe"<< endl;
                break;
        }
    }while ( ele < 5) ; // Mientras While
    return 0;
}


void insertarLista(Nodo *&lista,int n,string a,string b,string c,int tel){
	Nodo *nuevo_nodo = new struct Nodo;
	
	nuevo_nodo->id = n;
        nuevo_nodo->Nombre=a;
        nuevo_nodo->ciudad=b;
        nuevo_nodo->direccion=c;
        nuevo_nodo->numero=tel;
        
	Nodo *aux1 = lista;
	Nodo *aux2;
	
	while((aux1 != NULL) && (aux1->Nombre < a)){
		aux2 = aux1;
		aux1 = aux1->siguiente;
	}
	
	if(lista == aux1){
		lista = nuevo_nodo;
	}
	else{
		aux2->siguiente = nuevo_nodo;
	}
	
	nuevo_nodo->siguiente = aux1;
	
	cout<<"\nID : "<<n<<" Insertado a lista correctamente\n";
}


void mostrarLista(Nodo *lista){
	Nodo *actual = new Nodo();
	actual = lista;
	
        cout << "*********Libreta**********" << endl;
	while(actual != NULL){
        if(actual->id != 0){
            cout<<actual->id<<" -> ";
		
                        cout << "Informacion " << endl;
                        cout << "1.- ID :" << actual->id<< endl;
                        cout << "2.- Nombre :" << actual->Nombre<< endl;
                        cout << "3.- Telefono :" << actual->numero<< endl;
                        cout << "4.- Dirreccion :" <<actual->direccion<< endl;
                        cout << "5.- Ciudad :" << actual->ciudad<< endl;
                         cout << "*************************"<<endl;
                     
            }
         actual = actual->siguiente;
	}
        if(actual == NULL){
            cout << "NULL"<<endl;
        }
        
}

void buscarLista(Nodo *lista, int valor)
{
    Nodo *q = lista;
    int i = 1, band = 0;
 
    while(q  != NULL)
    {
        if( q->id==valor && q->id != 0)
        {
            cout<<endl<<"Encontrada en posicion "<< i <<endl;
            cout<<endl<<"Su Nombre es: "<< q->Nombre <<endl;
            cout<<endl<<"Su Ciudad es :"<< q->ciudad <<endl;
            cout<<endl<<"Su Direccion es :"<< q->direccion <<endl;
            cout<<endl<<"Su Telefono es : "<<q->numero<<endl;
            cout <<"\n";
            band = 1;
        }else{
            cout<< "No se encuentra el elemento "<<endl;
        }
        q = q->siguiente;
        i++;
    }
}


void borrar(Nodo *lista,int n ){
    Nodo *q = lista ;
    Nodo *ant;
    int i =1, band=0;
    
    
    while (q != NULL){
        ant= NULL;
               if(q->id != n){
                   cout << "Valor no encontrado"<<endl; 
               }else{
                   ant = q;
                   cout << "Posicion es " << i << endl;
                   delete(ant);
               } 
               q=q->siguiente;
               i++;
    }
    if(lista == NULL){
        cout << "No hay elementos en la lista";
    }
  
 }